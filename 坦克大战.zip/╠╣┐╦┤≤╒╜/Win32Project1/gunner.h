#pragma once
#include<windows.h>
#include"resource.h"
#include <iostream>
using namespace std;
class gunner
{
public:
	gunner(void);
	~gunner(void);
	public:
	 HBITMAP m_hBmpGunner;
	int x;
	int y;
	int m_nFX;

public:
 void gunner::InitGunner(HINSTANCE hIns,int FX, int x1, int y1);
	 void MoveGunner();
	 void ShowGunner(HDC hdc);

};

