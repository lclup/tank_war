#include "gunnerbox.h"


gunnerbox::gunnerbox(void)
{
}


gunnerbox::~gunnerbox(void)
{
	list<gunner*>::iterator ito=m_gunner.begin();
	while(ito!=m_gunner.end())
	{
		delete(*ito);
		ito=m_gunner.erase(ito);
	}
}
void gunnerbox::allgunnershow(HDC hdc)
{
    list<gunner*>::iterator ito=m_gunner.begin();
	while(ito!=m_gunner.end())
	{
		 (*ito) ->ShowGunner(hdc);
		ito++;
	}
}
void gunnerbox::allgunnermove()
{
	bool falg=true;
	list<gunner*>::iterator ito=m_gunner.begin();
	while(ito!=m_gunner.end())
	{
		 (*ito)->MoveGunner();
		 if( (*ito)->x<0||(*ito)->x>1122||(*ito)->y<0||(*ito)->y>594)
		 {
			 delete(*ito);
			 ito=m_gunner.erase(ito);
			 falg=false;
		 }
		 if(falg==true)
		 {
		ito++;
		 }
		 falg=true;
	 }
}