#pragma once
#include"foetank.h"
#include<windows.h>
#include"gunner.h"
#include"gunnerbox.h"
#include<list>
class foetankbox
{
public:
	foetankbox(void);
	~foetankbox(void);
public:
	list<foetank*> m_foe;
	int ID;//��¼��������̹�˵�����
public:
	void allfoeshow(HDC hdc);
	void allfoecreate(HINSTANCE hins);
	void allfoemove(/*int FX,*/back &nb);
	void  allfoegunner (HINSTANCE hins,gunnerbox&gunnerb);
	 
};

