#include "gunner.h"


gunner::gunner(void)
{
	 m_hBmpGunner=0;
	 x=0;
	 y=0;
	 m_nFX=VK_UP;
}


gunner::~gunner(void)
{
	DeleteObject(m_hBmpGunner);
	m_hBmpGunner=0;

}
 void gunner::InitGunner(HINSTANCE hIns,int FX, int x1, int y1)
	 {
     m_hBmpGunner=LoadBitmap(hIns,MAKEINTRESOURCE(IDB_BITMAP13));
	 x=x1+21;
	 y=y1+21;
  m_nFX=FX;

	 }
 void gunner:: MoveGunner()
	 {
       if(m_nFX == VK_RIGHT)
			x+=40;
		if(m_nFX == VK_LEFT)
			x-=40;
		if(m_nFX == VK_DOWN)
			y+=40;
		if(m_nFX == VK_UP)
			y-=40;
	}
 void gunner::ShowGunner(HDC hdc)
	 {
		 HDC hNemDC = CreateCompatibleDC(hdc);
		SelectObject(hNemDC,m_hBmpGunner);
		BitBlt(hdc,x,y,8,8,hNemDC,0,0,SRCCOPY);
		DeleteDC(hNemDC);
	 }
