#pragma once
#include<windows.h>
#include"resource.h"
#include <iostream>
using namespace std;
class back
{
public:
	back(void);
	~back(void);
public:
	HBITMAP m_back;
	HBITMAP m_back1;
	HBITMAP m_back2;
	HBITMAP m_back3;
 	int arr[9][17];
public:
	void showback(HDC hdc);
	void initback(HINSTANCE hins);

};

