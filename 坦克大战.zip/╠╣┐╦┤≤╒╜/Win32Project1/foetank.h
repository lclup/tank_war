#pragma once
#include<windows.h>
#include"resource.h"
#include"back.h"
#include <iostream>
 
using namespace std;
class foetank
{
public:
	foetank(void);
	~foetank(void);
public:
	int x;
	int y;
	HBITMAP m_foeLEFT;
	HBITMAP m_foeRIGHT;
	HBITMAP m_foeUP;
	HBITMAP m_foeDOWN;
	int m_nFX;
public: 
	void initfoe(HINSTANCE hins);
	void foeshow(HDC hdc );
	void  foemove(/*int FX,*/back &nb );
	
};

