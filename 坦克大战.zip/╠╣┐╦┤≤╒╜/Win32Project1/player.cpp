#include "player.h"

player::player(void)
{
	x=0;
    y=0;
    m_playerLEFT=0;
    m_playerRIGHT=0;
    m_playerUP=0;
    m_playerDOWN=0;
    m_nFX = VK_UP;
}   
player::~player(void)
{
	DeleteObject(m_playerLEFT);
	m_playerLEFT=0;
	DeleteObject(m_playerRIGHT);
	m_playerRIGHT=0;
	DeleteObject(m_playerUP);
	m_playerUP=0;
	DeleteObject(m_playerDOWN);
	m_playerDOWN=0;
}
void player::initplay(HINSTANCE hins)
{
	x=400;
	y=544;
	m_playerLEFT=LoadBitmap(hins,MAKEINTRESOURCE(IDB_BITMAP10));
	m_playerRIGHT=LoadBitmap(hins,MAKEINTRESOURCE(IDB_BITMAP9));
	m_playerUP=LoadBitmap(hins,MAKEINTRESOURCE(IDB_BITMAP7 ));
	m_playerDOWN=LoadBitmap(hins,MAKEINTRESOURCE(IDB_BITMAP8));

}
void player::playshow(HDC hdc )
{
	HDC menhdc=CreateCompatibleDC(hdc);
	if(m_nFX==VK_UP)
	{
		 
		SelectObject(menhdc,m_playerUP);
	}
	if(m_nFX==VK_DOWN)
	{
		SelectObject(menhdc,m_playerDOWN);
	}
	if(m_nFX==VK_LEFT)
	{
		SelectObject(menhdc,m_playerLEFT);
	}
	if(m_nFX==VK_RIGHT)
	{
		SelectObject(menhdc,m_playerRIGHT);
	}
	BitBlt(hdc,x,y,50,50,menhdc,0,0,SRCCOPY);
	DeleteDC(menhdc);
}
void player::playmove(int FX,back &nb )
{
	 
 
	if(FX == VK_RIGHT)
	
		{
			if(x<1122-50 )
			{
			 
				if(nb.arr[y/66][(x+50)/66]!=0)
				{
                   x=x;
				}
				else if(nb.arr[(y+50)/66][(x+50)/66]!=0)
				{
					x=x;
				}
				else
				{
m_nFX = VK_RIGHT;
			x+=4;
			}
			}
		}
		if(FX == VK_LEFT)
		{
			if(x>0 ) 
			{ 
				if(nb.arr[y/66-1][x/66]!=0)
				{
                   x=x;
				}
				else if(nb.arr[(y)/66][x/66]!=0)
				{
					x=x;
				}
				else
				{
m_nFX = VK_LEFT;
			x-=4;
			}
			}
		}
		if(FX == VK_UP)
		{
			if(y>0  )
			{ 
				if(nb.arr[y/66][x/66]!=0)
				{
                   y=y;
				}
				else if(nb.arr[(y)/66][(x+50)/66]!=0)
				{
					 y=y;
				}
				else
				{
 m_nFX = VK_UP;
			      y-=4;
			}
			
			}
		}
		if(FX == VK_DOWN)
		{
			if(y<594-50  )
			{
				 
				if(nb.arr[(y+50)/66][x/66]!=0)
				{
                   y=y;
				}
				else if(nb.arr[(y+50)/66][(x+50)/66]!=0)
				{
					 y=y;
				}
				else
				{
 m_nFX = VK_DOWN;
			        y+=4;
			}
			
		}
		}
	 
		}