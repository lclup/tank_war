#pragma 
#include<windows.h>
#include"resource.h"
#include"back.h"
#include <iostream>
using namespace std;
class player
{
public:
	int x;
	int y;
	HBITMAP m_playerLEFT;
	HBITMAP m_playerRIGHT;
	HBITMAP m_playerUP;
	HBITMAP m_playerDOWN;
	
	int m_nFX;
public:
	player(void);
	~player(void);
public:
	void initplay(HINSTANCE hins);
	void playshow(HDC hdc );
	void  playmove(int FX,back &nb );
};

