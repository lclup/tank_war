#include "foetankbox.h"


foetankbox::foetankbox(void)
{
	ID=0;
}


foetankbox::~foetankbox(void)
{
	list<foetank*> ::iterator ito=m_foe.begin();
	while( ito!=m_foe.end())
		{
          delete(*ito);
          ito=m_foe.erase(ito);
		}
}
void foetankbox::allfoeshow(HDC hdc)
{
	list<foetank*> ::iterator ito=m_foe .begin();
	while( ito!=m_foe.end())
		{
              (*ito)->foeshow(hdc);
              ito++;
		}

}
void foetankbox::allfoecreate(HINSTANCE hins)
{
 
	   foetank *foe=new foetank;
	   foe->initfoe(hins);
	   m_foe.push_back(foe);
	   ID++;
		 
}
void foetankbox::allfoemove(/*int FX,*/back &nb)
{
	list<foetank*> ::iterator ito=m_foe .begin();
	while( ito!=m_foe.end())
	  {
        (*ito)->foemove(/*FX,*/nb);
        ito++;
	 }
}
void  foetankbox::allfoegunner (HINSTANCE hins,gunnerbox&gunnerb)
{
   list<foetank*> ::iterator ito=m_foe .begin();
   while( ito!=m_foe.end())
		{
			if((*ito)!=0)
			{
               gunner*gunn =new gunner;
               gunn->InitGunner(hins,(*ito)->m_nFX,(*ito)->x,(*ito)->y);
               gunnerb.m_gunner.push_back(gunn);
			}
    ito++;
		}
}
	 
