#include <windows.h>
#include"back.h"
#include"player.h"
#include"gunner.h"
#include"foetankbox.h"
#include"gunnerbox.h"
#include<time.h>

LRESULT CALLBACK WindowProc(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam);
HINSTANCE hIns = 0;

int CALLBACK WinMain(HINSTANCE hInstance,HINSTANCE hPreInstance,LPSTR lpCmdLine,int nShowCmd)
{
	//-----------------------------------------------------
	HWND hwnd = 0;
	MSG msg;       //  װ��Ϣ�Ľṹ��
	WNDCLASSEX wndclass;
	//-----------------------------------------------------
	
	hIns = hInstance;

	//----------------------�������ڹ���-----------------------------------
	//  1. ���
	//CreateSolidBrush(RGB(0,0,0));
	wndclass.cbClsExtra = 0;
	wndclass.cbWndExtra = 0;
	wndclass.cbSize = sizeof(wndclass);
	wndclass.hbrBackground = CreateSolidBrush(RGB(0,0,0));
	wndclass.hCursor = LoadCursor(0,MAKEINTRESOURCE(IDC_ARROW));
	wndclass.hIcon = 0;
	wndclass.hIconSm = 0;
	wndclass.hInstance = hInstance;
	wndclass.lpfnWndProc = WindowProc;
	wndclass.lpszClassName = L"���";
	wndclass.lpszMenuName = 0;
	wndclass.style = CS_HREDRAW|CS_VREDRAW;
	// 2.  ע��
	if(RegisterClassEx(&wndclass) == FALSE)
	{
		MessageBox(0,L"ע��ʧ��",L"��ʾ",MB_OK);
		return 0;
	}
	//  3.  ����
	hwnd = CreateWindow( L"���",L"̹�˴�ս",WS_OVERLAPPEDWINDOW,0,0,1122+16,594+38,0,0,hInstance,0);
	if(hwnd == 0)
	{
		MessageBox(0,L"����ʧ��",L"��ʾ",MB_OK);
		return 0;	
	}
	//  4.  ��ʾ����
	ShowWindow(hwnd,SW_SHOW);
	//---------------------------�������ڹ���------------------------------------------------



	//----------------------------��Ϣѭ��-------------------------------------------
	while(GetMessage(&msg,0,0,0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	//----------------------------��Ϣѭ��-------------------------------------------

	return 0;
}
back b;
player er;
gunner*gun=0;
foetankbox fbox;
gunnerbox gunnerb;
bool isgameover();  //�ж��Ƿ���Ϸ����    1.�����ڵ����Լ�   2.�����ڵ����
void gunnerhitfoe();//����ڵ��������
void gunnerhitback();//����ڵ����򱳾�
bool foehitplayer();// �жϵ����ڵ��Ƿ���Լ�
void  foehitback();//�����ڵ��򱳾�
bool foehithome();  //�жϵ����ڵ��Ƿ�򵽼�
bool ffalg=true;//����һ�����

//=================================������Ϣ========================================================
LRESULT CALLBACK WindowProc(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_CREATE:
		{
		srand(unsigned int(time(NULL)));//��һ�����������
		SetTimer(hwnd, 1,50,0);//����ƶ�
		SetTimer(hwnd,2,50,0);//��ҷ����ڵ��ƶ�
		SetTimer(hwnd,3,6000,0);//��������
		SetTimer(hwnd,4,500,0);//���е����ƶ�
		SetTimer(hwnd,5,200,0);//�����ڵ��ƶ�
		SetTimer(hwnd,6,6000,0);//���˷����ڵ�
		b.initback(hIns);
		er.initplay(hIns);
		}
		break;
	case WM_PAINT:
		{
		PAINTSTRUCT ps={0};
		HDC hdc=BeginPaint(hwnd,&ps);
		HDC menhdc=CreateCompatibleDC(hdc); 
       HBITMAP bitmap=CreateCompatibleBitmap(hdc,1122,594); 
       SelectObject(menhdc,bitmap);   
		b.showback(menhdc);
		er.playshow(menhdc);
		fbox.allfoeshow(menhdc);
		gunnerb.allgunnershow(menhdc);
		if(gun != 0)
		gun->ShowGunner(menhdc);
		BitBlt(hdc,0,0,1122,594,menhdc,0,0,SRCCOPY);   
        DeleteDC(menhdc) ;
        DeleteObject(bitmap); 
		EndPaint(hwnd,&ps);
		}
		break;
	case WM_KEYDOWN:
	{
			 
	if(wParam == VK_SPACE)//���¿ո� ���ڵ�
			{
				//delete gun;   
				gun = new gunner;   
				gun->InitGunner(hIns,er.m_nFX,er.x,er.y);
			}
			//  �ػ�
			RECT rect = {0,0,500,500};
			InvalidateRect(hwnd,&rect,FALSE);
	}
		break;
	case WM_TIMER:
	{
		if(wParam==1)
		{
				 if(::GetAsyncKeyState(VK_UP))
					 er.playmove(VK_UP,b);
				 if(::GetAsyncKeyState(VK_DOWN))
					er.playmove(VK_DOWN,b);
				 if(::GetAsyncKeyState(VK_LEFT))
					 er.playmove(VK_LEFT,b);
				 if(::GetAsyncKeyState(VK_RIGHT))
					er.playmove(VK_RIGHT,b);
		}
	if(wParam==2)
		{
			if(gun != 0)
			{
			gun->MoveGunner();
			if( (gun)->x<0||(gun)->x>1122||(gun)->y<0||(gun)->y>594)//�ж��ӵ��Ƿ���߽�
			      {
				delete gun;
				gun=0;
			      }
			}
			gunnerhitfoe();
			gunnerhitback();

		}
if(wParam==3)
{
	if(ffalg==true)
			{
			 fbox.allfoecreate(hIns);
			}
	if(fbox.ID==10)//�趨����10��̹��
			  {
			 ffalg=false;
            if(fbox.m_foe.size()==0)//�����е���̹����ʧ  you win
			          {
				        KillTimer(hwnd,1);//����ƶ�
					    KillTimer(hwnd,2);//��ҷ����ڵ��ƶ�
					    KillTimer(hwnd,3);//��������
					    KillTimer(hwnd,4);//���е����ƶ�
					    KillTimer(hwnd,5);//�����ڵ��ƶ�
					    KillTimer(hwnd,6);//���˷����ڵ�
					     MessageBox(hwnd,L"you win!",L"��ʾ",MB_OK);
			           }
			   }

}
if(wParam==4)
{
			  
 fbox.allfoemove(b);		 

}
if(wParam==5)
{
			  
 gunnerb.allgunnermove();
 foehitback();
 if(foehitplayer()==true||foehithome()==true)//�жϵ����˻�����һ��ߵ��˻��м� ��Ϸ����
	    {		
			KillTimer(hwnd, 1);//����ƶ�
			KillTimer(hwnd,2);//��ҷ����ڵ��ƶ�
			KillTimer(hwnd,3);//��������
			KillTimer(hwnd,4);//���е����ƶ�
			KillTimer(hwnd,5);//�����ڵ��ƶ�
			KillTimer(hwnd,6);//���˷����ڵ�
		    MessageBox(hwnd,L"game over!",L"��ʾ",MB_OK);	 
		 }
}
if(wParam==6)
{  
	fbox.allfoegunner(hIns,gunnerb); //����ͬ�ĵ���̹�˴����ڵ�
}
		RECT rect={0,0,1122,594};
		InvalidateRect(hwnd,&rect,FALSE);
}
		break;
	case WM_CLOSE:
		PostQuitMessage(0);
		break;
}
	return DefWindowProc( hwnd, uMsg, wParam, lParam);
}


void gunnerhitfoe()
{
	bool flag=true;
	list<foetank*> ::iterator ito=fbox.m_foe .begin();
		while( ito!=fbox.m_foe.end())
		{
		if(gun!=0)
	      {
              if(gun->x>(*ito)->x&&gun->x<(*ito)->x+50&&gun->y>(*ito)->y&&gun->y<(*ito)->y+50)
                   {
	                  delete(*ito);
		              delete gun;   
		              gun=0;
		              ito=fbox.m_foe .erase(ito);
		              flag=false;

                   }
		 }
        if( flag==true)
          {
	        ito++;
	
          }
     flag=true;
		}

}
void gunnerhitback()
{
   if(gun!=0)
      {
           if(b.arr[gun->y/66][gun->x/66]==2)
               {
	  
	              b.arr[gun->y/66][gun->x/66]=0;     
	              delete gun; 
	              gun=0;
		       }
       }
  if(gun!=0)
	{
		  if(b.arr[gun->y/66][gun->x/66]==4)
               {     
	             delete gun; 
	             gun=0;

               }
    }
}
bool foehitplayer()
{
	list<gunner*>::iterator ito=gunnerb.m_gunner.begin();
    while(ito!=gunnerb.m_gunner.end())
     {
	       if((*ito)->x>er.x&&(*ito)->x<er.x+50&&(*ito)->y>er.y&&(*ito)->y<er.y+50)
	          {
		           return true;
	           }
     	ito++;
      }
	return false;

}
bool foehithome()
{
	list<gunner*>::iterator ito=gunnerb.m_gunner.begin();
	if(gunnerb.m_gunner.size()>1)
	{
         while(ito!=gunnerb.m_gunner.end())
               {
	                 if(  b.arr[(*ito)->y/66][(*ito)->x/66]==1)
	                    {
                            return true;
	                     }
	          ito++;
               }
	}
	return false;
}
void  foehitback()
{
  bool flagb=true;
  bool flag=true;
  list<gunner*>::iterator ito=gunnerb.m_gunner.begin();
   if(gunnerb.m_gunner.size()>1)
	{
          while(ito!=gunnerb.m_gunner.end())
             {
	             if(b.arr[(*ito)->y/66][(*ito)->x/66]==2)
	                  {
		                  b.arr[(*ito)->y/66][(*ito)->x/66]=0;
		                  delete(*ito);
		                  ito=gunnerb.m_gunner.erase(ito);
		                  flag=false;
		                  flagb=false;
	                  }
	           if(flagb==true)
	              {
	                  if(b.arr[(*ito)->y/66][(*ito)->x/66]==4)
	                       {
		                     delete(*ito);
		                     ito=gunnerb.m_gunner.erase(ito);
		                     flag=false;
	                         flagb=true;
                           	}
	               }
	       flagb=true;
	          if( flag==true)
                   {
	                  ito++;
                   }
          flag=true;
             }
    }
}
