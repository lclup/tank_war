#pragma once
#include"gunner.h"
#include<list>
class gunnerbox
{
public:
	gunnerbox(void);
	~gunnerbox(void);
public:
	list<gunner*> m_gunner;
	void allgunnershow(HDC hdc);
	void allgunnermove();

};

