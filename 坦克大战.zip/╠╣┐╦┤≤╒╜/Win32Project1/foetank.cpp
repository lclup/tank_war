#include "foetank.h"


foetank::foetank(void)
{
	  x=0;
	  y=0;
	  m_foeLEFT=0;
	  m_foeRIGHT=0;
	  m_foeUP=0;
	  m_foeDOWN=0;
	  m_nFX=VK_DOWN;
}


foetank::~foetank(void)
{
	DeleteObject(m_foeLEFT);
	m_foeLEFT=0;
	DeleteObject(m_foeRIGHT);
	m_foeRIGHT=0;
	DeleteObject(m_foeUP);
	m_foeUP=0;
	DeleteObject(m_foeDOWN);
	m_foeDOWN=0;
}
void foetank::initfoe(HINSTANCE hins)
{
switch(rand()%3)
{
case 1:
	x=0;
	break;
	case 2 :
	x=460;
	break;
	case 0:
	x=1072;
	break;
}
y=0;
   m_foeLEFT=LoadBitmap(hins,MAKEINTRESOURCE(IDB_BITMAP4));
   m_foeRIGHT=LoadBitmap(hins,MAKEINTRESOURCE(IDB_BITMAP5));
   m_foeUP=LoadBitmap(hins,MAKEINTRESOURCE(IDB_BITMAP2));
   m_foeDOWN=LoadBitmap(hins,MAKEINTRESOURCE(IDB_BITMAP3));
}
	
void foetank::foeshow(HDC hdc )
{
		
	HDC menhdc=CreateCompatibleDC(hdc);
	if(m_nFX==VK_UP)
	{
		SelectObject(menhdc,m_foeUP);
	}
	if(m_nFX==VK_DOWN)
	{
		SelectObject(menhdc,m_foeDOWN);
	}
	if(m_nFX==VK_LEFT)
	{
		SelectObject(menhdc,m_foeLEFT);
	}
	if(m_nFX==VK_RIGHT)
	{
		SelectObject(menhdc,m_foeRIGHT);
	}
	BitBlt(hdc,x,y,50,50,menhdc,0,0,SRCCOPY);
	DeleteDC(menhdc);
	}
	
void foetank:: foemove(/*int FX,*/back &nb )
	{
	 
      
		switch(rand()%6)
		{     
		case  1:
		{
					 // if(FX == VK_RIGHT)
	
	/*	{*/
			if(x<1122-50 )
			{
			 
			 
				if(nb.arr[y/66][(x+50)/66]!=0)
				{
                   x=x;
				}
				else if(nb.arr[(y+50)/66][(x+50)/66]!=0)
				{
					x=x;
				}
				else
				{
m_nFX = VK_RIGHT;
			x+=10;
			}
			}
			
		/*}*/
				  }
			break;
	case  0:
{
//if(FX == VK_DOWN)
		/*{*/
			if(y<594-50  )
			{
				 
				if(nb.arr[(y+50)/66][x/66]!=0)
				{
                   y=y;
				}
				else if(nb.arr[(y+50)/66][(x+50)/66]!=0)
				{
					 y=y;
				}
				else
				{
 m_nFX = VK_DOWN;
			        y+=8;
			}
			
		}
	}
			break;
 case  2:
{
		/*				if(FX == VK_DOWN)
		{*/
if(y<594-50  )
			{
				 
				if(nb.arr[(y+50)/66][x/66]!=0)
				{
                   y=y;
				}
				else if(nb.arr[(y+50)/66][(x+50)/66]!=0)
				{
					 y=y;
				}
				else
				{
 m_nFX = VK_DOWN;
			        y+=8;
			}
			
		}
		/*}*/

}
			break;
 case  3:
{
//if(FX == VK_LEFT)
//		{
			if(x>0 ) 
			{
				 
				if(nb.arr[y/66-1][x/66]!=0)
				{
                   x=x;
				}
				else if(nb.arr[(y)/66][x/66]!=0)
				{
					x=x;
				}
				else
				{
m_nFX = VK_LEFT;
			x-=10;
			}
			}
	/*	}*/
}
			break;
case  4:
{
//if(FX == VK_DOWN)
//		{
		if(y<594-50  )
			{
				 
				if(nb.arr[(y+50)/66][x/66]!=0)
				{
                   y=y;
				}
				else if(nb.arr[(y+50)/66][(x+50)/66]!=0)
				{
					 y=y;
				}
				else
				{
 m_nFX = VK_DOWN;
			        y+=8;
			}
			
		}
 

}
			break;
 case  5:
{
//if(FX == VK_UP)
//		{
			if(y>0  )
			{
				if(nb.arr[y/66][x/66]!=0)
				{
                   y=y;
				}
				else if(nb.arr[(y)/66][(x+50)/66]!=0)
				{
					 y=y;
				}
				else
				{
 m_nFX = VK_UP;
			      y-=2;
			}
			
			}

}
		break;				 
}

}

	

