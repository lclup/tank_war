#include "back.h"

back::back(void)
{
	m_back=0;
	m_back1=0;
	m_back2=0;
	m_back3=0;
}
back::~back(void)
{
	DeleteObject(m_back);
	m_back=0;
	DeleteObject(m_back1);
	m_back1=0;
	DeleteObject(m_back2);
	m_back2=0;
	DeleteObject(m_back3);
	m_back3=0;
}
void back::showback(HDC hdc)
{
	HDC menhdc=CreateCompatibleDC(hdc);
	for(int i=0;i<9;i++)
	{
		for(int j=0;j<17;j++)
		{
			if(arr[i][j]==1)//�������� �жϷ���ʲôͼƬ   ��
			{
SelectObject(menhdc,m_back);
BitBlt(hdc,j*66,i*66,66,66,menhdc,0,0,SRCCOPY);

			}
			if(arr[i][j]==2) //ש��
			{
SelectObject(menhdc,m_back1);
BitBlt(hdc,j*66,i*66,66,66,menhdc,0,0,SRCCOPY);
			}
			if(arr[i][j]==3) //�ݴ�
			{
SelectObject(menhdc,m_back2);
BitBlt(hdc,j*66,i*66,66,66,menhdc,0,0,SRCCOPY);
			}
			if(arr[i][j]==4)// ����
			{
SelectObject(menhdc,m_back3);
BitBlt(hdc,j*66,i*66,66,66,menhdc,0,0,SRCCOPY);
			}
		}
	}
	DeleteDC(menhdc);

}
	void back::initback(HINSTANCE hins)
{//����ͼƬ
		m_back=LoadBitmap(hins,MAKEINTRESOURCE(IDB_BITMAP6));
		m_back1=LoadBitmap(hins,MAKEINTRESOURCE(IDB_BITMAP12));
		m_back2=LoadBitmap(hins,MAKEINTRESOURCE(IDB_BITMAP1));
		m_back3=LoadBitmap(hins,MAKEINTRESOURCE(IDB_BITMAP11));
 //�����ļ�
		FILE* fp=0;
		if(fopen_s(&fp,"..\\res\\aa.txt","rb")==0)
		{
			for(int i=0;i<9;i++)
			{

				for(int j=0;j<17;j++)
				{
                  char c=fgetc(fp);
                  arr[i][j]=c-'0';

				}
				//ȡ����\r'  '\n'
				 fgetc(fp);
				 fgetc(fp);
			}
			fclose(fp);
		}
				
}


